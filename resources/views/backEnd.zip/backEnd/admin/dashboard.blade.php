@extends('backEnd.admin.layouts.master')

@section('title')
    Dashboard
@endsection

@php
    $net_profit = $data['net_profit'] ?? 0;
    $gross_profit = $data['gross_profit'] ?? 0;
    $total_expense = $data['total_expense'] ?? 0;
    $total_revenue = $data['total_revenue'] ?? 0;
    $profit_margin = $data['profit_margin'] ?? 0;
    $avg_order_value = $data['avg_order_value'] ?? 0;

    $total_customer = $data['total_customer'] ?? 0;
    $total_product = $data['total_product'] ?? 0;
    $total_staff = $data['total_staff'] ?? 0;
    $total_order = $data['total_order'] ?? 0;

    $total_pending_order = $data['total_pending_order'] ?? 0;
    $total_confirm_order = $data['total_confirm_order'] ?? 0;
    $total_processing_order = $data['total_processing_order'] ?? 0;
    $total_hold_order = $data['total_hold_order'] ?? 0;
    $total_printed_order = $data['total_printed_order'] ?? 0;
    $total_packaging_order = $data['total_packaging_order'] ?? 0;
    $total_courier_entry_order = $data['total_courier_entry_order'] ?? 0;
    $total_on_delivery_order = $data['total_on_delivery_order'] ?? 0;
    $total_delivered_order = $data['total_delivered_order'] ?? 0;
    $total_cancelled_order = $data['total_cancelled_order'] ?? 0;
    $total_returned_order = $data['total_returned_order'] ?? 0;
    $total_return_received_order = $data['total_return_received_order'] ?? 0;
    $total_exchange_order = $data['total_exchange_order'] ?? 0;
    $total_abandoned_order = $data['total_abandoned_order'] ?? 0;
    $total_trash_order = $data['total_trash_order'] ?? 0;

    $delivery_success_rate = $data['delivery_success_rate'] ?? 0;
    $return_rate = $data['return_rate'] ?? 0;
    $cancel_rate = $data['cancel_rate'] ?? 0;

    $top_selling_products = $data['top_selling_products'] ?? collect([]);

    $today_all_orders = $data['today_all_orders'] ?? 0;
    $today_pending_orders = $data['today_pending_order'] ?? 0;
    $today_confirm_orders = $data['today_confirm_order'] ?? 0;
    $today_processing_orders = $data['today_processing_order'] ?? 0;
    $today_hold_orders = $data['today_hold_order'] ?? 0;
    $today_printed_orders = $data['today_printed_order'] ?? 0;
    $today_packaging_orders = $data['today_packaging_order'] ?? 0;
    $today_on_delivery_orders = $data['today_on_delivery_order'] ?? 0;
    $today_courier_entry_orders = $data['today_courier_entry_order'] ?? 0;
    $today_delivered_orders = $data['today_delivered_order'] ?? 0;
    $today_cancelled_orders = $data['today_cancelled_order'] ?? 0;
    $today_returned_orders = $data['today_returned_order'] ?? 0;

    $recent_orders = $data['recent_orders'] ?? collect([]);
@endphp

@push('css')
    <link rel="stylesheet" type="text/css" href="{{ asset('backEnd/assets/plugin/datepicker/daterangepicker.css') }}" />
    <style>
        .biz-card {
            transition: all 0.25s ease-in-out;
            border: 1px solid rgba(0, 0, 0, 0.05) !important;
            border-radius: 12px;
        }

        .biz-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.06) !important;
        }

        .stat-icon {
            width: 46px;
            height: 46px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 10px;
        }

        .pipeline-card {
            border: 1px solid rgba(0, 0, 0, 0.06);
            border-radius: 10px;
            padding: 12px 16px;
            transition: all 0.2s ease-in-out;
        }

        .pipeline-card:hover {
            background-color: var(--tblr-bg-surface-secondary);
            border-color: rgba(0, 0, 0, 0.12);
        }

        .custom-scrollbar::-webkit-scrollbar {
            width: 5px;
            height: 5px;
        }

        .custom-scrollbar::-webkit-scrollbar-thumb {
            background: rgba(0, 0, 0, 0.15);
            border-radius: 10px;
        }
    </style>
@endpush

@section('content')
    <!-- Page Header, Date Range Filter & Quick Actions -->
    <div class="page-header d-print-none mb-3">
        <div class="container-xl">
            <div class="row g-2 align-items-center justify-content-between">
                <div class="col-md-5">
                    <div class="page-pretitle text-muted fw-semibold">Business Performance Dashboard</div>
                    <h2 class="page-title fw-bold text-dark">Executive Overview</h2>
                </div>

                <!-- Date Range Filter & Quick Actions -->
                <div class="col-md-7 d-flex justify-content-md-end align-items-center gap-2 flex-wrap">
                    <!-- Date Range Form -->
                    <form action="{{ route('admin.home') }}" method="GET" class="d-flex align-items-center gap-2"
                        id="dashboard_filter_form">
                        <div>
                            <input type="text" placeholder="Select date range" id="date_range_display"
                                class="form-control search-input  form-control-sm date_range date_range_display"
                                autocomplete="off"
                                value="{{ isset($start) && isset($end) ? \Carbon\Carbon::parse($start)->format('Y-m-d') . ' - ' . \Carbon\Carbon::parse($end)->format('Y-m-d') : request('date_range') }}">
                            <input type="hidden" name="date_range" id="date_range" value="{{ request('date_range') }}">
                        </div>
                        <button type="submit" class="btn btn-sm btn-gradient-primary d-flex align-items-center gap-1">
                            <i class="ti ti-filter me-1"></i> Filter
                        </button>
                        @if (request()->filled('date_range'))
                            <a href="{{ route('admin.home') }}"
                                class="btn btn-sm btn-gradient-danger d-flex align-items-center gap-1" title="Reset Filter"
                                style="height: 27px;text-align: center;">
                                <i class="ti ti-x"></i>
                            </a>
                        @endif
                    </form>

                    <!-- Quick Action Buttons -->
                    <div class="btn-list">
                        {{-- @can('orders.create') --}}
                        <a href="{{ route('admin.orders.create') }}"
                            class="btn btn-sm btn-gradient-primary d-flex align-items-center gap-1">
                            <i class="ti ti-plus me-1"></i> Create Order
                        </a>
                        {{-- @endcan --}}
                        {{-- @can('product.create') --}}
                        <a href="{{ route('admin.product.create') }}"
                            class="btn btn-sm btn-gradient-success d-flex align-items-center gap-1">
                            <i class="ti ti-box me-1"></i> Add Product
                        </a>
                        {{-- @endcan --}}
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <div class="page-body">
        <div class="container-xl">

            <!-- SECTION 1: Profit & Loss Statement Summary -->
            <div class="row row-cards mb-3 g-3">

                {{-- Net Profit --}}
                <div class="col-sm-6 col-lg-4 col-xl-3 mt-0">
                    <div class="card biz-card shadow-sm">
                        <div class="card-body p-3">
                            <div class="d-flex align-items-center justify-content-between mb-2">
                                <span class="text-uppercase text-muted fw-bold fs-6">Net Profit</span>
                                <div class="stat-icon bg-success-lt text-success">
                                    <i class="ti ti-cash fs-1"></i>
                                </div>
                            </div>
                            <div class="h1 mb-1 fw-extrabold {{ $net_profit < 0 ? 'text-danger' : 'text-success' }}">
                                <span>{{ $web_settings->currency_sign }}</span>
                                <span>{{ number_format($net_profit, 2) }}</span>
                            </div>
                            <div class="text-muted small d-flex align-items-center justify-content-between">
                                <span>Net Margin: <strong>{{ $profit_margin }}%</strong></span>
                                <span
                                    class="badge {{ $net_profit >= 0 ? 'bg-success-lt text-success' : 'bg-danger-lt text-danger' }}">
                                    {{ $net_profit >= 0 ? 'Profitable' : 'Loss' }}
                                </span>
                            </div>
                        </div>
                    </div>
                </div>

                {{-- Gross Profit --}}
                <div class="col-sm-6 col-lg-4 col-xl-3 mt-0">
                    <div class="card biz-card shadow-sm">
                        <div class="card-body p-3">
                            <div class="d-flex align-items-center justify-content-between mb-2">
                                <span class="text-uppercase text-muted fw-bold fs-6">Gross Profit</span>
                                <div class="stat-icon bg-primary-lt text-primary">
                                    <i class="ti ti-chart-bar fs-1"></i>
                                </div>
                            </div>
                            <div class="h1 mb-1 fw-extrabold text-dark">
                                <span>{{ $web_settings->currency_sign }}</span>
                                <span>{{ number_format($gross_profit, 2) }}</span>
                            </div>
                            <div class="text-muted small d-flex align-items-center gap-1">
                                <span class="badge bg-primary-lt text-primary">Revenue</span>
                                <span>Sales - Product Cost</span>
                            </div>
                        </div>
                    </div>
                </div>

                {{-- Total Expense --}}
                <div class="col-sm-6 col-lg-4 col-xl-3 mt-0">
                    <div class="card biz-card shadow-sm">
                        <div class="card-body p-3">
                            <div class="d-flex align-items-center justify-content-between mb-2">
                                <span class="text-uppercase text-muted fw-bold fs-6">Total Expenses</span>
                                <div class="stat-icon bg-danger-lt text-danger">
                                    <i class="ti ti-report-money fs-1"></i>
                                </div>
                            </div>
                            <div class="h1 mb-1 fw-extrabold text-dark">
                                <span>{{ $web_settings->currency_sign }}</span>
                                <span>{{ number_format($total_expense, 2) }}</span>
                            </div>
                            <div class="text-muted small d-flex align-items-center gap-1">
                                <span class="badge bg-danger-lt text-danger">Outgoings</span>
                                <span>Ads, Courier, Rent etc</span>
                            </div>
                        </div>
                    </div>
                </div>

                {{-- Total Sales Revenue --}}
                <div class="col-sm-6 col-lg-4 col-xl-3 mt-0">
                    <div class="card biz-card shadow-sm">
                        <div class="card-body p-3">
                            <div class="d-flex align-items-center justify-content-between mb-2">
                                <span class="text-uppercase text-muted fw-bold fs-6">Total Delivered Sales</span>
                                <div class="stat-icon bg-azure-lt text-azure">
                                    <i class="ti ti-currency-dollar fs-1"></i>
                                </div>
                            </div>
                            <div class="h1 mb-1 fw-extrabold text-dark">
                                <span>{{ $web_settings->currency_sign }}</span>
                                <span>{{ number_format($total_revenue, 2) }}</span>
                            </div>
                            <div class="text-muted small d-flex align-items-center gap-1">
                                <span>Avg Order Value:
                                    <strong>{{ $web_settings->currency_sign }}{{ number_format($avg_order_value, 2) }}</strong></span>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

            <!-- SECTION: Visual Analytics Charts -->
            {{-- <div class="row row-cards mb-3 g-3">
                <div class="col-lg-8">
                    <div class="card border-0 shadow-sm rounded-3 h-100">
                        <div
                            class="card-header bg-transparent border-bottom d-flex align-items-center justify-content-between">
                            <h3 class="card-title fw-bold">
                                <i class="ti ti-chart-area-line me-2 text-primary"></i>Sales & Profit Trends
                            </h3>
                        </div>
                        <div class="card-body">
                            <div id="sales-trend-chart" style="height: 300px;"></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card border-0 shadow-sm rounded-3 h-100">
                        <div
                            class="card-header bg-transparent border-bottom d-flex align-items-center justify-content-between">
                            <h3 class="card-title fw-bold">
                                <i class="ti ti-chart-donut me-2 text-success"></i>Courier Distribution
                            </h3>
                        </div>
                        <div class="card-body d-flex align-items-center justify-content-center">
                            <div id="courier-donut-chart" style="height: 300px; width: 100%;"></div>
                        </div>
                    </div>
                </div>
            </div> --}}





            <!-- SECTION 2: Order Lifecycle Pipeline & Overall Health -->
            <div class="row row-cards mb-3 g-3">

                {{-- Order Processing Pipeline --}}
                <div class="col-xl-8 col-lg-7">
                    <div class="card border-0 shadow-sm h-100 rounded-3">
                        <div
                            class="card-header bg-transparent border-bottom d-flex align-items-center justify-content-between">
                            <h3 class="card-title fw-bold">
                                <i class="ti ti-git-commit me-2 text-primary"></i>Order Fulfillment Pipeline
                            </h3>
                            @if (isset($start) && isset($end))
                                <span class="badge bg-primary-lt">
                                    {{ $start->format('d M Y') }} - {{ $end->format('d M Y') }}
                                </span>
                            @endif
                        </div>
                        <div class="card-body p-3">
                            <div class="row g-2">
                                <div class="col-6 col-sm-4 col-md-3">
                                    <a href="{{ route('admin.orders', ['status' => 'pending']) }}"
                                        class="text-decoration-none">
                                        <div class="pipeline-card">
                                            <div class="text-muted fs-6 fw-semibold">Pending</div>
                                            <div class="h2 mb-0 text-warning fw-bold">
                                                {{ number_format($total_pending_order) }}</div>
                                        </div>
                                    </a>
                                </div>
                                <div class="col-6 col-sm-4 col-md-3">
                                    <a href="{{ route('admin.orders', ['status' => 'confirm']) }}"
                                        class="text-decoration-none">
                                        <div class="pipeline-card">
                                            <div class="text-muted fs-6 fw-semibold">Confirmed</div>
                                            <div class="h2 mb-0 text-primary fw-bold">
                                                {{ number_format($total_confirm_order) }}</div>
                                        </div>
                                    </a>
                                </div>
                                <div class="col-6 col-sm-4 col-md-3">
                                    <a href="{{ route('admin.orders', ['status' => 'processing']) }}"
                                        class="text-decoration-none">
                                        <div class="pipeline-card">
                                            <div class="text-muted fs-6 fw-semibold">Processing</div>
                                            <div class="h2 mb-0 text-info fw-bold">
                                                {{ number_format($total_processing_order) }}</div>
                                        </div>
                                    </a>
                                </div>
                                <div class="col-6 col-sm-4 col-md-3">
                                    <a href="{{ route('admin.orders', ['status' => 'hold']) }}"
                                        class="text-decoration-none">
                                        <div class="pipeline-card">
                                            <div class="text-muted fs-6 fw-semibold">Hold</div>
                                            <div class="h2 mb-0 text-purple fw-bold">
                                                {{ number_format($total_hold_order) }}</div>
                                        </div>
                                    </a>
                                </div>
                                <div class="col-6 col-sm-4 col-md-3">
                                    <a href="{{ route('admin.orders', ['status' => 'packaging']) }}"
                                        class="text-decoration-none">
                                        <div class="pipeline-card">
                                            <div class="text-muted fs-6 fw-semibold">Packaging</div>
                                            <div class="h2 mb-0 text-orange fw-bold">
                                                {{ number_format($total_packaging_order) }}</div>
                                        </div>
                                    </a>
                                </div>
                                <div class="col-6 col-sm-4 col-md-3">
                                    <a href="{{ route('admin.orders', ['status' => 'courier_entry']) }}"
                                        class="text-decoration-none">
                                        <div class="pipeline-card">
                                            <div class="text-muted fs-6 fw-semibold">Courier Entry</div>
                                            <div class="h2 mb-0 text-blue fw-bold">
                                                {{ number_format($total_courier_entry_order) }}</div>
                                        </div>
                                    </a>
                                </div>
                                <div class="col-6 col-sm-4 col-md-3">
                                    <a href="{{ route('admin.orders', ['status' => 'on_delivery']) }}"
                                        class="text-decoration-none">
                                        <div class="pipeline-card">
                                            <div class="text-muted fs-6 fw-semibold">On Delivery</div>
                                            <div class="h2 mb-0 text-azure fw-bold">
                                                {{ number_format($total_on_delivery_order) }}</div>
                                        </div>
                                    </a>
                                </div>
                                <div class="col-6 col-sm-4 col-md-3">
                                    <a href="{{ route('admin.orders', ['status' => 'delivered']) }}"
                                        class="text-decoration-none">
                                        <div class="pipeline-card">
                                            <div class="text-muted fs-6 fw-semibold">Delivered</div>
                                            <div class="h2 mb-0 text-success fw-bold">
                                                {{ number_format($total_delivered_order) }}</div>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {{-- Business Health Metrics & Cancel Ratio Overview --}}
                <div class="col-xl-4 col-lg-5">
                    <div class="card border-0 shadow-sm h-100 rounded-3">
                        <div
                            class="card-header bg-transparent border-bottom d-flex align-items-center justify-content-between">
                            <h3 class="card-title fw-bold">
                                <i class="ti ti-activity me-2 text-success"></i>Business Health Ratios
                            </h3>
                            @if (isset($start) && isset($end))
                                <span class="badge bg-primary-lt">
                                    {{ $start->format('d M Y') }} - {{ $end->format('d M Y') }}
                                </span>
                            @endif
                        </div>
                        <div class="card-body p-3 d-flex flex-column justify-content-between">
                            <div>
                                <div class="d-flex justify-content-between align-items-center mb-1">
                                    <span class="text-muted fw-semibold">Delivery Success Ratio</span>
                                    <span class="fw-bold text-success">{{ $delivery_success_rate }}%</span>
                                </div>
                                <div class="progress progress-sm mb-2">
                                    <div class="progress-bar bg-success" style="width: {{ $delivery_success_rate }}%">
                                    </div>
                                </div>

                                <div class="d-flex justify-content-between align-items-center mb-1">
                                    <span class="text-muted fw-semibold">Return Ratio (Loss Factor)</span>
                                    <span class="fw-bold text-danger">{{ $return_rate }}%</span>
                                </div>
                                <div class="progress progress-sm mb-2">
                                    <div class="progress-bar bg-danger" style="width: {{ $return_rate }}%"></div>
                                </div>

                                {{-- Cancel Ratio Widget --}}
                                <div class="d-flex justify-content-between align-items-center mb-1">
                                    <span class="text-muted fw-semibold">Cancel Ratio</span>
                                    <span class="fw-bold text-warning">{{ $cancel_rate }}%</span>
                                </div>
                                <div class="progress progress-sm mb-3">
                                    <div class="progress-bar bg-warning" style="width: {{ $cancel_rate }}%"></div>
                                </div>
                            </div>

                            <div class="row text-center g-2 pt-2 border-top">
                                <div class="col-4">
                                    <div class="text-muted fs-6">Customers</div>
                                    <div class="h3 mb-0 fw-bold text-dark">{{ number_format($total_customer) }}</div>
                                </div>
                                <div class="col-4">
                                    <div class="text-muted fs-6">Products</div>
                                    <div class="h3 mb-0 fw-bold text-primary">{{ number_format($total_product) }}</div>
                                </div>
                                <div class="col-4">
                                    <div class="text-muted fs-6">Staffs</div>
                                    <div class="h3 mb-0 fw-bold text-info">{{ number_format($total_staff) }}</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

            <!-- SECTION 3: Today's Detailed Report, Stock Alert & Top Selling -->
            <div class="row row-cards mb-3 g-3">

                {{-- Today's Full Breakdown --}}
                {{-- Today's Full Breakdown / Filtered Breakdown --}}
                <div class="col-xl-4 col-lg-6">
                    <div class="card border-0 shadow-sm h-100 rounded-3">
                        <div
                            class="card-header bg-transparent border-bottom d-flex align-items-center justify-content-between">
                            <h3 class="card-title fw-bold">
                                <i class="ti ti-calendar-stats me-2 text-primary"></i>
                                Order Breakdown
                            </h3>
                            {{-- start & end  show --}}
                            @if (isset($start) && isset($end))
                                <span class="badge bg-primary-lt">
                                    {{ $start->format('d M Y') }} - {{ $end->format('d M Y') }}
                                </span>
                            @endif

                        </div>
                        <div class="card-body p-0">
                            <!-- বাকী টেবিল কোড অপরিবর্তিত থাকবে -->
                            <div class="table-responsive custom-scrollbar" style="max-height: 380px; overflow-y: auto;">
                                <table class="table table-vcenter card-table table-hover">
                                    <tbody>
                                        @php
                                            $todayStats = [
                                                'All Orders' => ['val' => $today_all_orders, 'class' => 'bg-secondary'],
                                                'Pending' => ['val' => $today_pending_orders, 'class' => 'bg-warning'],
                                                'Confirmed' => [
                                                    'val' => $today_confirm_orders,
                                                    'class' => 'bg-primary',
                                                ],
                                                'Processing' => [
                                                    'val' => $today_processing_orders,
                                                    'class' => 'bg-info',
                                                ],
                                                'Hold' => ['val' => $today_hold_orders, 'class' => 'bg-purple'],
                                                'Printed' => ['val' => $today_printed_orders, 'class' => 'bg-cyan'],
                                                'Packaging' => [
                                                    'val' => $today_packaging_orders,
                                                    'class' => 'bg-orange',
                                                ],
                                                'Courier Entry' => [
                                                    'val' => $today_courier_entry_orders,
                                                    'class' => 'bg-blue',
                                                ],
                                                'On Delivery' => [
                                                    'val' => $today_on_delivery_orders,
                                                    'class' => 'bg-azure',
                                                ],
                                                'Delivered' => [
                                                    'val' => $today_delivered_orders,
                                                    'class' => 'bg-success',
                                                ],
                                                'Cancelled' => [
                                                    'val' => $today_cancelled_orders,
                                                    'class' => 'bg-danger',
                                                ],
                                                'Returned' => ['val' => $today_returned_orders, 'class' => 'bg-pink'],
                                                'Return Received' => [
                                                    'val' => $data['today_return_received_order'] ?? 0,
                                                    'class' => 'bg-teal',
                                                ],
                                                'Exchanged' => [
                                                    'val' => $data['today_exchange_order'] ?? 0,
                                                    'class' => 'bg-indigo',
                                                ],
                                            ];
                                        @endphp
                                        @foreach ($todayStats as $key => $item)
                                            <tr>
                                                <td>
                                                    <span class="badge {{ $item['class'] }} me-2"
                                                        style="margin: 5px 0px;"></span>
                                                    <span class="text-secondary fw-medium">{{ $key }}</span>
                                                </td>
                                                <td class="text-end fw-bold text-dark">{{ number_format($item['val']) }}
                                                </td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                {{-- Low Stock Warning --}}
                <div class="col-xl-4 col-lg-6">
                    <div class="card border-0 shadow-sm h-100 rounded-3">
                        <div
                            class="card-header bg-transparent border-bottom d-flex align-items-center justify-content-between">
                            <h3 class="card-title fw-bold text-warning">
                                <i class="ti ti-alert-triangle me-2"></i>Stock Warning
                            </h3>
                            <a href="{{ route('admin.product') }}" class="btn btn-sm btn-ghost-warning">Catalog</a>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive custom-scrollbar" style="max-height: 380px; overflow-y: auto;">
                                @php
                                    $setting = DB::table('web_settings')->first();
                                    $stock_alert = $setting->stock_alert ?? 0;
                                    $products = DB::table('products')
                                        ->when($stock_alert > 0, function ($q) use ($stock_alert) {
                                            $q->where('stock', '<=', $stock_alert);
                                        })
                                        ->take(6)
                                        ->get();
                                @endphp
                                <table class="table table-vcenter card-table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Product Name</th>
                                            <th class="text-end">Stock</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @forelse ($products as $p)
                                            <tr>
                                                <td class="text-truncate" style="max-width: 180px;">{{ $p->name }}
                                                </td>
                                                <td class="text-end">
                                                    <span class="badge bg-warning-lt text-warning fw-bold px-2 py-1">
                                                        {{ $p->stock }} Pcs
                                                    </span>
                                                </td>
                                            </tr>
                                        @empty
                                            <tr>
                                                <td colspan="2" class="text-center text-muted py-4">
                                                    <i class="ti ti-circle-check text-success fs-2 d-block mb-1"></i>
                                                    Stock levels are healthy.
                                                </td>
                                            </tr>
                                        @endforelse
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                {{-- Top Selling Products --}}
                <div class="col-xl-4 col-lg-12">
                    <div class="card border-0 shadow-sm h-100 rounded-3">
                        <div
                            class="card-header bg-transparent border-bottom  d-flex align-items-center justify-content-between">
                            <h3 class="card-title fw-bold">
                                <i class="ti ti-flame me-2 text-danger"></i>Top Selling Products
                            </h3>
                            @if (isset($start) && isset($end))
                                <span class="badge bg-primary-lt">
                                    {{ $start->format('d M Y') }} - {{ $end->format('d M Y') }}
                                </span>
                            @endif
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive custom-scrollbar" style="max-height: 380px; overflow-y: auto;">
                                <table class="table table-vcenter card-table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Product Name</th>
                                            <th class="text-end">Total Sold</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @forelse ($top_selling_products as $product)
                                            <tr>
                                                <td class="text-truncate fw-semibold text-dark" style="max-width: 180px;">
                                                    {{ $product->name }}
                                                </td>
                                                <td class="text-end">
                                                    <span class="badge bg-primary-lt text-primary fw-bold px-2 py-1">
                                                        {{ $product->total_sold }} Sold
                                                    </span>
                                                </td>
                                            </tr>
                                        @empty
                                            <tr>
                                                <td colspan="2" class="text-center text-muted py-4">No top selling
                                                    products found.</td>
                                            </tr>
                                        @endforelse
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

            <!-- SECTION 4: Courier, Expense, Financial Accounts & Staff Workload -->
            <div class="row row-cards mb-3 g-3">

                {{-- Courier Distribution Breakdown --}}
                <div class="col-xl-3 col-lg-6 col-md-6">
                    <div class="card border-0 shadow-sm h-100 rounded-3">
                        <div
                            class="card-header bg-transparent border-bottom d-flex align-items-center justify-content-between">
                            <h3 class="card-title fw-bold fs-5">
                                <i class="ti ti-truck me-1 text-azure"></i>Courier Wise
                            </h3>
                            @if (isset($start) && isset($end))
                                <span class="badge bg-primary-lt">
                                    {{ $start->format('d M Y') }} - {{ $end->format('d M Y') }}
                                </span>
                            @endif
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive custom-scrollbar" style="max-height: 320px; overflow-y: auto;">
                                <table class="table table-vcenter card-table table-hover fs-6">
                                    <tbody>
                                        @forelse ($data['courier_breakdown'] ?? [] as $courierItem)
                                            @php
                                                $courierNames = [
                                                    1 => 'Steadfast',
                                                    2 => 'Pathao',
                                                    3 => 'Redx',
                                                    4 => 'Carrybee',
                                                ];
                                                $cName =
                                                    $courierNames[$courierItem->courier_id] ??
                                                    'Courier #' . $courierItem->courier_id;
                                            @endphp
                                            <tr>
                                                <td class="text-dark">{{ $cName }}</td>
                                                <td class="text-end">
                                                    <span class="badge bg-azure-lt text-azure fw-bold">
                                                        {{ number_format($courierItem->total) }}
                                                    </span>
                                                </td>
                                            </tr>
                                        @empty
                                            <tr>
                                                <td colspan="2" class="text-center text-muted py-3">No data</td>
                                            </tr>
                                        @endforelse
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                {{-- Expense Category Breakdown --}}
                <div class="col-xl-3 col-lg-6 col-md-6">
                    <div class="card border-0 shadow-sm h-100 rounded-3">
                        <div
                            class="card-header bg-transparent border-bottom d-flex align-items-center justify-content-between">
                            <h3 class="card-title fw-bold fs-5">
                                <i class="ti ti-chart-pie me-1 text-danger"></i>Expense Categories
                            </h3>
                            @if (isset($start) && isset($end))
                                <span class="badge bg-primary-lt">
                                    {{ $start->format('d M Y') }} - {{ $end->format('d M Y') }}
                                </span>
                            @endif
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive custom-scrollbar" style="max-height: 320px; overflow-y: auto;">
                                <table class="table table-vcenter card-table table-hover fs-6">
                                    <tbody>
                                        @forelse ($data['expense_categories'] ?? [] as $exp)
                                            <tr>
                                                <td class="text-dark">{{ $exp->get_category->name ?? 'General' }}</td>
                                                <td class="text-end fw-bold text-danger">
                                                    {{ $web_settings->currency_sign }}{{ number_format($exp->total_amount, 2) }}
                                                </td>
                                            </tr>
                                        @empty
                                            <tr>
                                                <td colspan="2" class="text-center text-muted py-3">No expense</td>
                                            </tr>
                                        @endforelse
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                {{-- Financial Accounts Balance Overview --}}
                <div class="col-xl-3 col-lg-6 col-md-6">
                    <div class="card border-0 shadow-sm h-100 rounded-3">
                        <div
                            class="card-header bg-transparent border-bottom d-flex align-items-center justify-content-between">
                            <h3 class="card-title fw-bold fs-5">
                                <i class="ti ti-wallet me-1 text-success"></i>Accounts Balance
                            </h3>
                            @if (isset($start) && isset($end))
                                <span class="badge bg-primary-lt">
                                    {{ $start->format('d M Y') }} - {{ $end->format('d M Y') }}
                                </span>
                            @endif
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive custom-scrollbar" style="max-height: 320px; overflow-y: auto;">
                                <table class="table table-vcenter card-table table-hover fs-6">
                                    <tbody>
                                        @forelse ($data['accounts_balance'] ?? [] as $acc)
                                            {{-- @dd($acc) --}}
                                            <tr>
                                                <td class="text-dark">{{ $acc->get_account_name() }}</td>
                                                <td class="text-end fw-bold text-success">
                                                    {{ $web_settings->currency_sign }}{{ number_format($acc->balance, 2) }}
                                                </td>
                                            </tr>
                                        @empty
                                            <tr>
                                                <td colspan="2" class="text-center text-muted py-3">No accounts
                                                    configured</td>
                                            </tr>
                                        @endforelse
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                {{-- Staff Workload / Order Assignment Breakdown --}}
                <div class="col-xl-3 col-lg-6 col-md-6">
                    <div class="card border-0 shadow-sm h-100 rounded-3">
                        <div class="card-header bg-transparent border-bottom">
                            <h3 class="card-title fw-bold fs-5">
                                <i class="ti ti-users me-1 text-info"></i>Staff Workload
                            </h3>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive custom-scrollbar" style="max-height: 320px; overflow-y: auto;">
                                <table class="table table-vcenter card-table table-hover fs-6">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th class="text-end">Status</th>
                                            <th class="text-end">Orders</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @forelse ($data['staff_order_breakdown'] ?? [] as $staff)
                                            <tr>
                                                <td class="text-dark">
                                                    {{ $staff->name }}
                                                </td>
                                                <td class="text-end">
                                                    @if ($staff->status == 1)
                                                        <span class="badge bg-success">Active</span>
                                                    @else
                                                        <span class="badge bg-danger">Inactive</span>
                                                    @endif
                                                </td>
                                                <td class="text-end">
                                                    <span class="badge bg-info-lt text-info fw-bold">
                                                        {{ number_format($staff->assigned_orders_count) }}
                                                    </span>
                                                </td>
                                            </tr>
                                        @empty
                                            <tr>
                                                <td colspan="3" class="text-center text-muted py-3">No staff
                                                    assignments</td>
                                            </tr>
                                        @endforelse
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

            </div>


        </div>
    </div>
@endsection

@push('js')
    <script src="{{ asset('backEnd/assets/plugin/datepicker/moment.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('backEnd/assets/plugin/datepicker/daterangepicker.js') }}"></script>
    <script>
        $(document.body).ready(function() {
            var $dateInput = $('#date_range_display');

            $dateInput.daterangepicker({
                autoUpdateInput: false,
                locale: {
                    cancelLabel: 'Clear',
                    format: 'YYYY-MM-DD'
                },
                ranges: {
                    'Today': [moment(), moment()],
                    'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                    'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                    'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                    'This Month': [moment().startOf('month'), moment().endOf('month')],
                    'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1,
                        'month').endOf('month')]
                }
            });

            // Handle selection
            $dateInput.on('apply.daterangepicker', function(ev, picker) {
                var formattedRange = picker.startDate.format('YYYY-MM-DD') + ' - ' + picker.endDate.format(
                    'YYYY-MM-DD');
                $(this).val(formattedRange);
                $('#date_range').val(formattedRange);
            });

            // Handle clear action
            $dateInput.on('cancel.daterangepicker', function(ev, picker) {
                $(this).val('');
                $('#date_range').val('');
            });
        });
    </script>
    <!-- ApexCharts CDN (যদি থিমে অলরেডি না থাকে) -->
    <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            // ১. Sales & Profit Trend Area Chart
            var salesOptions = {
                chart: {
                    type: 'area',
                    height: 300,
                    toolbar: {
                        show: false
                    },
                },
                series: [{
                    name: 'Revenue',
                    data: [31, 40, 28, 51, 42, 109,
                        100
                    ] // আপনার কন্ট্রোলার থেকে আসা ডাইনামিক ডেটা এখানে পাস করতে পারেন
                }, {
                    name: 'Net Profit',
                    data: [11, 32, 45, 32, 34, 52, 41]
                }],
                xaxis: {
                    categories: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
                },
                colors: ['#206bc4', '#2fb344'],
                dataLabels: {
                    enabled: false
                },
                stroke: {
                    curve: 'smooth',
                    width: 2
                },
                fill: {
                    type: 'gradient',
                    gradient: {
                        opacityFrom: 0.5,
                        opacityTo: 0.1
                    }
                }
            };
            var salesChart = new ApexCharts(document.querySelector("#sales-trend-chart"), salesOptions);
            salesChart.render();

            // ২. Courier Distribution Donut Chart
            var courierOptions = {
                chart: {
                    type: 'donut',
                    height: 300,
                },
                series: [44, 55, 13, 33], // কুরিয়ার ব্রেকডাউন ডেটা
                labels: ['Steadfast', 'Pathao', 'Redx', 'Carrybee'],
                colors: ['#206bc4', '#f59f00', '#d63939', '#2fb344'],
                legend: {
                    position: 'bottom'
                }
            };
            var courierChart = new ApexCharts(document.querySelector("#courier-donut-chart"), courierOptions);
            courierChart.render();
        });
    </script>
@endpush

@extends('backEnd.admin.layouts.master')
@section('title')
    Purchase
@endsection
@php
    $setting = DB::table('web_settings')->select('currency_sign')->where('id', 1)->first();
@endphp
@section('content')
    <div class="page-body mt-3">
        <div class="container-xl">
            <div class="row">
                <div class="col-12 d-flex justify-content-between align-items-center">
                    <h2 class="page-title">Purchase List</h2>
                    <div class="d-flex align-items-center gap-2">
                        <div class="d-flex align-items-center gap-1">
                            <span class="fw-bold">Total:</span>
                            <span class="badge bg-primary text-white">{{ $data->total() }}</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row row-deck row-cards mt-2">
                <!-- Page Header Close -->
                <div class="col-12 m-0">
                    <div class="card" style="border-top:none">
                        <div class="card-header d-flex  align-items-center gap-2 py-2">
                            @can('purchases.create')
                                <a href="{{ route('admin.purchase.create') }}" class="btn btn-success btn-sm add_supplier">
                                    <i class="ti ti-plus"></i>
                                    Add Purchase</a>
                            @endcan
                            {{-- Clean Production Bulk Delete Button --}}
                            <button type="button" id="bulk_delete_btn"
                                class="btn btn-gradient-danger btn-sm d-flex align-items-center gap-1">
                                <i class="ti ti-trash"></i> Bulk Delete
                                <span id="selected_count" class="badge bg-white text-danger ms-1 d-none">0</span>
                            </button>

                        </div>
                        <div class="table-responsive">
                            @include('backEnd.admin.includes.top-paginate', ['items' => $data])
                            <table class="table table-vcenter card-table">
                                <thead>
                                    <tr class="align-middle">
                                        <th class="w-1">
                                            SL. <input class="form-check-input m-0 align-middle" type="checkbox"
                                                aria-label="Select all invoices" id="master">
                                        </th>
                                        <th>Date</th>
                                        <th>Supplier</th>
                                        <th>Total</th>
                                        <th>Discount</th>
                                        <th>Due</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @if (count($data) > 0)
                                        @php
                                            $i = 1;
                                        @endphp
                                        @foreach ($data as $key => $item)
                                            <tr @if ($key + (1 % 2) == 0) style="background-color:#f5f5f5" @endif>
                                                <td class="sl-cell">
                                                    {{ $i++ }}.
                                                    <input class="form-check-input m-0 align-middle sub_chk" type="checkbox"
                                                        data-id="{{ $item->id }}">
                                                </td>
                                                <td>
                                                    {{ date('d M Y', strtotime($item->purchase_date)) }}
                                                </td>

                                                <td>{{ $item->get_supplier->name }}</td>
                                                <td>{{ $setting->currency_sign }}
                                                    {{ number_format($item->subtotal, 2, '.', '') }}</td>
                                                <td>{{ $setting->currency_sign }}
                                                    {{ number_format($item->discount, 2, '.', '') }}</td>
                                                <td>{{ $setting->currency_sign }}
                                                    {{ number_format($item->due_amount, 2, '.', '') }}</td>
                                                <td>
                                                    @if ($item->status == 0)
                                                        <span class="badge bg-warning dropdown-toggle"
                                                            data-bs-toggle="dropdown">Pending</span>

                                                        {{-- // dropdown
                                                        <div class="dropdown">
                                                            <button class="btn btn btn-cyan border-0 btn-sm d-flex justify-content-center gap-1 dropdown-toggle"
                                                                type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown"
                                                                aria-expanded="false">
                                                                Action
                                                            </button>
                                                            <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                                                                <li><a class="dropdown-item"
                                                                        href="">Order</a>
                                                                </li>
                                                                <li><a class="dropdown-item"
                                                                        href="">Received</a>
                                                                </li>
                                                            </ul>
                                                        </div> --}}
                                                    @elseif($item->status == 1)
                                                        <span class="badge bg-info dropdown-toggle">Ordered</span>
                                                    @elseif($item->status == 2)
                                                        <span class="badge bg-success dropdown-toggle">Received</span>
                                                    @endif


                                                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                                                        <li><a class="dropdown-item {{ $item->status == 0 ? 'd-none' : '' }}"
                                                                href="{{ route('admin.purchase.status', [$item->id, 'status' => 0]) }}">Pending</a>
                                                        </li>
                                                        <li><a class="dropdown-item  {{ $item->status == 1 ? 'd-none' : '' }}"
                                                                href="{{ route('admin.purchase.status', [$item->id, 'status' => 1]) }}">Ordered</a>
                                                        </li>
                                                        <li><a class="dropdown-item  {{ $item->status == 2 ? 'd-none' : '' }}"
                                                                href="{{ route('admin.purchase.status', [$item->id, 'status' => 2]) }}">Received</a>
                                                        </li>

                                                    </ul>


                                                </td>
                                                <td class="w-1">
                                                    @can('purchases.edit')
                                                        <a href="{{ route('admin.purchase.edit', $item->id) }}"
                                                            class="btn-gradient-info  padding-2-6 border-0 btn-sm w-100 mb-1 d-flex justify-content-center align-items-center rounded gap-1">
                                                            <i class="ti ti-edit"></i> Edit
                                                        </a>
                                                    @endcan
                                                    <form action="{{ route('admin.purchase.delete', $item->id) }}"
                                                        method="POST">
                                                        @csrf
                                                        @method('DELETE')
                                                        @can('purchases.delete')
                                                            <button type="submit"
                                                                class="btn-gradient-danger  padding-2-6 border-0 btn-sm w-100 mb-1 d-flex justify-content-center align-items-center rounded gap-1"
                                                                onclick="return confirm('Are you sure want to delete this?')"><i
                                                                    class="ti ti-trash"></i>
                                                                Delete</button>
                                                        @endcan
                                                    </form>
                                                </td>
                                            </tr>
                                        @endforeach
                                    @else
                                        <tr>
                                            <td colspan="10" class="text-center"> <span class="text-danger"><b>No data
                                                        found.</b></span></td>
                                        </tr>
                                    @endif
                                </tbody>
                            </table>
                            @include('backEnd.admin.includes.bottom-paginate', ['items' => $data])
                        </div>

                        {{-- <div>
                            {{ $data->links('backEnd.admin.includes.paginate') }}

                        </div> --}}
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection
@push('js')
    <script>
        $(document).ready(function() {

            // ১. Master Checkbox Toggle
            $(document).on('change', '#master', function() {
                let isChecked = $(this).is(':checked');
                $('.sub_chk').prop('checked', isChecked).trigger('change');
            });

            // ২. Row Selection & Badge Update Logic
            $(document).on('change', '.sub_chk', function() {
                let $row = $(this).closest('tr');

                // Check/Uncheck UI highlight
                if ($(this).is(':checked')) {
                    $row.addClass('table-primary');
                } else {
                    $row.removeClass('table-primary');
                    $('#master').prop('checked', false);
                }

                // Count Update
                let totalChecked = $('.sub_chk:checked').length;
                if (totalChecked > 0) {
                    $('#selected_count').removeClass('d-none').text(totalChecked);
                } else {
                    $('#selected_count').addClass('d-none').text(0);
                }
            });

            // ৩. Bulk Delete Action with SweetAlert2 & AJAX
            $(document).on('click', '#bulk_delete_btn', function(e) {
                e.preventDefault();

                let selectedIds = [];
                $('.sub_chk:checked').each(function() {
                    selectedIds.push($(this).data('id'));
                });

                // যদি কোনো চেকবাক্স সিলেক্ট না থাকে
                if (selectedIds.length === 0) {
                    Swal.fire({
                        icon: 'warning',
                        title: 'No Items Selected',
                        text: 'Please select at least one item to delete.',
                        confirmButtonColor: '#0054a6'
                    });
                    return;
                }

                // Confirmation Alert
                Swal.fire({
                    title: 'Are you sure?',
                    text: `You are about to delete ${selectedIds.length} item(s)! This cannot be undone.`,
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#d33',
                    cancelButtonColor: '#6c757d',
                    confirmButtonText: 'Yes, Delete All',
                    cancelButtonText: 'Cancel',
                    reverseButtons: true
                }).then((result) => {
                    if (result.isConfirmed) {
                        // Loader Alert
                        Swal.fire({
                            title: 'Deleting...',
                            text: 'Please wait while we delete selected items.',
                            allowOutsideClick: false,
                            didOpen: () => {
                                Swal.showLoading();
                            }
                        });

                        // AJAX Request
                        $.ajax({
                            url: "{{ route('admin.purchase.bulk.delete') }}",
                            type: "POST",
                            data: {
                                ids: selectedIds,
                                _token: "{{ csrf_token() }}"
                            },
                            success: function(res) {
                                if (res.success) {
                                    Swal.fire({
                                        icon: 'success',
                                        title: 'Deleted!',
                                        text: res.message,
                                        timer: 1500,
                                        showConfirmButton: false
                                    }).then(() => {
                                        // Reload or DOM remove (Reload safer for pagination count)
                                        location.reload();
                                    });
                                } else {
                                    Swal.fire({
                                        icon: 'error',
                                        title: 'Failed',
                                        text: res.message ||
                                            'Something went wrong!',
                                    });
                                }
                            },
                            error: function(xhr) {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Server Error',
                                    text: xhr.responseJSON?.message ||
                                        'Failed to process request. Please try again.',
                                });
                            }
                        });
                    }
                });
            });

        });
    </script>
@endpush

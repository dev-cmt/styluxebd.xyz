@extends('backEnd.admin.layouts.master')

@section('title')
    Courier Reports
@endsection
@php
    $setting = DB::table('web_settings')->first();
    // $products = $data['products'];
@endphp

@push('css')
    <style>
        .select2-container--default .select2-selection--single {
            height: 23px;
            border-radius: 3px;
        }

        .select2-container--default .select2-selection--single .select2-selection__rendered {
            line-height: 18px !important;
            font-size: 12px !important;
        }

        .select2-container--default .select2-selection--single .select2-selection__arrow {
            height: 13px;
        }

        .select2-container--default .select2-selection--single {
            padding: .1rem 2.25rem .1rem .75rem;
        }
    </style>
    <link rel="stylesheet" type="text/css" href="{{ asset('backEnd/assets/plugin/datepicker/daterangepicker.css') }}" />
@endpush

@section('content')
    <div class="page-body mt-3">
        <div class="container-xl">
            <div class="row">
                <h3>
                    Courier Status Reports
                </h3>
            </div>
            <div class="row excel-export d-flex justify-content-between">
                <div class="col-md-6 col-12 mb-1">
                    <form action="" method="GET">
                        <input type="hidden" name="export" value="1">
                        <input type="hidden" class="start_date" name="start_date" value="{{ $start ?? null }}">
                        <input type="hidden" class="end_date" name="end_date" value="{{ $end ?? null }}">
                        <button type="submit" class="btn btn-success btn-sm pdf-button"><svg
                                xmlns="http://www.w3.org/2000/svg" width="19" height="19" viewBox="0 0 24 24"
                                fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                stroke-linejoin="round" class="icon icon-tabler icons-tabler-outline icon-tabler-download">
                                <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                <path d="M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2 -2v-2" />
                                <path d="M7 11l5 5l5 -5" />
                                <path d="M12 4l0 12" />
                            </svg>CSV Export</button>
                    </form>
                </div>
                <div class="col-md-4 col-12 ">
                    <form class="d-flex justify-content-end" action="#" method="GET" id="date_range_form">
                        <input type="hidden" class="start_date" name="start_date">
                        <input type="hidden" class="end_date" name="end_date">
                        <input type="text" class="form-control form-control-sm small-search date_range me-2"
                            placeholder="Date Range..." autocomplete="off" value="{{ $daterange ?? null }}"
                            name="date_range">
                        <a href="{{ route('admin.report.courier') }}" class="btn btn-sm reset_button"><i
                                class="ti ti-refresh"></i></a>
                    </form>
                </div>
            </div>
            <div class="row my-2">
                <div class="col-12">
                    <div class="table-responsive mb-4">
                        <table class="table card-table  datatable table-bordered">
                            <thead>
                                <tr>
                                    <th>SL.</th>
                                    <th>Name</th>
                                    <th>Pending </th>
                                    <th>Confirmed</th>
                                    <th>Processing</th>
                                    <th>Hold</th>
                                    <th>Printed</th>
                                    <th>Packaging</th>
                                    <th>Courier Entry</th>
                                    <th>On Delivery</th>
                                    <th>Delivered</th>
                                    <th>Cancelled</th>
                                    <th>Returned</th>
                                    <th>Return Received</th>
                                    <th>Exchange</th>

                                </tr>
                            </thead>
                            <tbody>
                                @php($i = 1)

                                @foreach ($courierReports as $key => $item)
                                    {{-- @dd($item) --}}
                                    <tr @if ($i % 2 == 0) style="background-color:#f5f5f5" @endif>
                                        <td width="1%">{{ $i++ }}</td>
                                        <td>{{ $key }}</td>
                                        <td>{{ $item['pending'] }}</td>
                                        <td>{{ $item['confirmed'] }}</td>
                                        <td>{{ $item['processing'] }}</td>
                                        <td>{{ $item['hold'] }}</td>
                                        <td>{{ $item['printed'] }}</td>
                                        <td>{{ $item['packaging'] }}</td>
                                        <td>{{ $item['courier_entry'] }}</td>
                                        <td>{{ $item['on_delivery'] }}</td>
                                        <td>{{ $item['delivered'] }}</td>
                                        <td>{{ $item['cancelled'] }}</td>
                                        <td>{{ $item['returned'] }}</td>
                                        <td>{{ $item['return_received'] }}</td>
                                        <td>{{ $item['exchange'] }}</td>
                                    </tr>
                                @endforeach

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@push('js')
    <script src="{{ asset('backEnd/assets/plugin/datepicker/moment.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('backEnd/assets/plugin/datepicker/daterangepicker.js') }}"></script>
    {{-- <script>
        $(document).ready(function() {
            $('.select2').select2({
                width: 'resolve'
            });
        });
    </script> --}}
    <script>
        $(document).ready(function() {
            $('.date_range').daterangepicker({
                locale: {
                    format: 'YYYY-MM-DD'
                },
                autoUpdateInput: false
            });
            $('.date_range').on('apply.daterangepicker', function(ev, picker) {
                $('#start_date').val(picker.startDate.format('YYYY-MM-DD'));
                $('#end_date').val(picker.endDate.format('YYYY-MM-DD'));

            });
            $('.date_range').on('cancel.daterangepicker', function(ev, picker) {
                $(this).val('');
            });
        });
    </script>
    <script>
        $(document).ready(function() {
            $('.date_range').daterangepicker({
                autoUpdateInput: false,
                locale: {
                    format: 'DD/MM/YYYY',
                    applyLabel: 'Search'
                }
            });

            $('.date_range').on('apply.daterangepicker', function(ev, picker) {
                // $(this).val(picker.startDate.format('DD/MM/YYYY') + ' - ' + picker.endDate.format(
                //     'DD/MM/YYYY'));
                // $('#range').val(picker.startDate.format('DD/MM/YYYY') + ' - ' + picker.endDate.format(
                //     'DD/MM/YYYY'));
                $('.start_date').val(picker.startDate.format('YYYY-MM-DD'));
                $('.end_date').val(picker.endDate.format('YYYY-MM-DD'));

                $('#date_range_form').submit();
            });

            $('.date_range').on('cancel.daterangepicker', function(ev, picker) {
                $(this).val('');
                $('#range').val('');
            });
        })
    </script>
@endpush

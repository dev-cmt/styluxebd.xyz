@extends('backEnd.admin.layouts.master')

@section('title')
    Supplier List
@endsection

@php
    $data = $data ?? [];
@endphp
@section('content')
    <div class="page-body mt-3">
        <div class="container-xl">
            <div class="row">
                <div class="col-12 d-flex justify-content-between align-items-center gap-2">
                    <h2 class="page-title">Supplier List</h2>
                    <div class="d-flex align-items-center gap-2">
                        <div class="d-flex align-items-center gap-1">
                            <span class="fw-bold">Total:</span>
                            <span class="badge bg-primary text-white">{{ $data->total() }}</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row row-deck row-cards mt-2">
                <!-- Page Header Close -->
                <div class="col-12 m-0">
                    <div class="card" style="border-top: none">
                        <div class="card-header d-flex align-items-center gap-2">
                            @can('suppliers.create')
                                <a href="javascript:void(0);" class="btn btn-success btn-sm add_btn"> <i class="ti ti-plus"></i>
                                    Add
                                    Supplier</a>
                            @endcan
                            {{-- Clean Production Bulk Delete Button --}}
                            <button type="button" id="bulk_delete_btn"
                                class="btn btn-gradient-danger btn-sm d-flex align-items-center gap-1">
                                <i class="ti ti-trash"></i> Bulk Delete
                                <span id="selected_count" class="badge bg-white text-danger ms-1 d-none">0</span>
                            </button>
                        </div>
                        <div class="table-responsive">
                            @include('backEnd.admin.includes.top-paginate', ['items' => $data])
                            <table class="table table-vcenter card-table">
                                <thead>
                                    <tr class="align-middle">
                                        <th class="w-1">
                                            SL. <input class="form-check-input m-0 align-middle" type="checkbox"
                                                aria-label="Select all invoices" id="master">
                                        </th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Phone</th>
                                        <th>Balance</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @php($i = 1)
                                    @if ($data->count() > 0)
                                        @foreach ($data as $item)
                                            <tr @if ($i % 2 == 0) style="background-color:#f5f5f5" @endif>
                                                <td class="sl-cell">
                                                    {{ $i++ }}.
                                                    <input class="form-check-input m-0 align-middle sub_chk" type="checkbox"
                                                        data-id="{{ $item->id }}">
                                                </td>
                                                <td>{{ $item->name }}</td>
                                                <td>{{ $item->email }}</td>
                                                <td>{{ $item->phone }}</td>
                                                <td>TK {{ number_format($item->balance, 2) }}</td>
                                                <td>
                                                    @can('suppliers.status')
                                                        @if ($item->status == 0)
                                                            <a href="{{ route('admin.supplier.status', ['id' => $item->id]) }}"
                                                                onclick="return confirm ('Are you sure do you want to Unblocked this?')"
                                                                class="badge bg-danger">
                                                                Block
                                                            </a>
                                                        @else
                                                            <a href="{{ route('admin.supplier.status', ['id' => $item->id]) }}"
                                                                onclick="return confirm ('Are you sure do you want to Block this?')"
                                                                class="badge bg-success">
                                                                Unblocked
                                                            </a>
                                                        @endif
                                                    @endcan
                                                </td>
                                                <td class="w-1">
                                                    @can('suppliers.edit')
                                                        <a href="javascript:void(0);"
                                                            class="btn-gradient-info padding-2-6 border-0 btn-sm w-100 mb-1 d-flex justify-content-center align-items-center rounded gap-1 edit-btn"
                                                            data-id="{{ $item->id }}" data-name="{{ $item->name }}"
                                                            data-email="{{ $item->email }}" data-phone="{{ $item->phone }}"
                                                            data-balance="{{ $item->balance }}"
                                                            data-status="{{ $item->status }}">
                                                            <i class="ti ti-edit"></i>Edit
                                                        </a>
                                                    @endcan
                                                    @can('suppliers.delete')
                                                        <a href="{{ route('admin.supplier.delete', $item->id) }}"
                                                            class="btn-gradient-danger padding-2-6 border-0 btn-sm w-100 mb-1 d-flex justify-content-center align-items-center rounded gap-1"
                                                            onclick="return confirm('Are you sure do delete this?')"><i
                                                                class="ti ti-trash"></i>Delete</a>
                                                    @endcan
                                                </td>
                                            </tr>
                                        @endforeach
                                    @else
                                        <tr>
                                            <td colspan="5" class="text-center text-danger font-weight-bold">No Media
                                                Found!</td>
                                        </tr>
                                    @endif
                                </tbody>
                            </table>
                            @include('backEnd.admin.includes.bottom-paginate', ['items' => $data])
                        </div>

                        {{-- <div>
                            {{ $data->links('backEnd.admin.includes.paginate') }}
                        </div> --}}

                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Add Modal -->
    <div class="modal modal-blur fade" id="add_modal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog  modal-md" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add Supplier</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="{{ route('admin.supplier.store') }}" method="post" enctype="multipart/form-data">
                        @csrf
                        <div class="form-group mb-3">
                            <label for="name">Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control mt-1" id="name" name="name" required>
                        </div>
                        <div class="form-group mb-3">
                            <label for="email">Email</label>
                            <input type="email" class="form-control mt-1" id="email" name="email">
                        </div>
                        <div class="form-group
                            mb-3">
                            <label for="phone">Phone <span class="text-danger">*</span></label>
                            <input type="text" class="form-control mt-1" id="phone" name="phone" required>
                        </div>
                        <div class="form-group
                            mb-3">
                            <label for="balance">Balance </label>
                            <input type="number" class="form-control mt-1" id="balance" name="balance">
                        </div>
                        <div class="form-group
                            mb-3">
                            <label for="status">Status</label>
                            <select name="status" id="status" class="form-control mt-1">
                                <option value="1">Active</option>
                                <option value="0">Inactive</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-success float-end">Create</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Edit Modal -->
    <div class="modal modal-blur fade" id="edit_modal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-md " role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Supplier</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="{{ route('admin.supplier.update') }}" method="post" enctype="multipart/form-data">
                        @csrf
                        <input type="hidden" id="id_e" name="id">
                        <div class="form-group
                            mb-3">
                            <label for="name">name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control mt-1" id="name_e" name="name" required>
                        </div>
                        <div class="form-group
                            mb-3">
                            <label for="email">Email</label>
                            <input type="email" class="form-control mt-1" id="email_e" name="email">
                        </div>
                        <div class="form-group
                            mb-3">
                            <label for="phone">Phone <span class="text-danger">*</span></label>
                            <input type="text" class="form-control mt-1" id="phone_e" name="phone" required>
                        </div>
                        <div class="form-group
                            mb-3">
                            <label for="balance">Balance</label>
                            <input type="number" class="form-control mt-1" id="balance_e" name="balance">
                        </div>
                        <div class="form-group
                            mb-3">
                            <label for="status">Status</label>
                            <select name="status" id="status_e" class="form-control mt-1">
                                <option value="1">Active</option>
                                <option value="0">Inactive</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-success float-end">Update</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

@endsection

@push('js')
    <script>
        $(document).on('click', '.edit_btn', function() {
            $('#edit_modal').modal('show');
            $('#id_e').val($(this).data('id'));
            $('#name_e').val($(this).data('name'));
            $('#email_e').val($(this).data('email'));
            $('#phone_e').val($(this).data('phone'));
            $('#balance_e').val(parseFloat($(this).data('balance')).toFixed(2));
            $('#status_e').val($(this).data('status'));
        });

        $(document).on('click', '.add_btn', function() {
            $('#add_modal').modal('show');
        });
    </script>
    <script>
        $(document).ready(function() {

            // ১. Master Checkbox Toggle
            $(document).on('change', '#master', function() {
                let isChecked = $(this).is(':checked');
                $('.sub_chk').prop('checked', isChecked).trigger('change');
            });

            // ২. Row Selection & Badge Update Logic
            $(document).on('change', '.sub_chk', function() {
                let $row = $(this).closest('tr');

                // Check/Uncheck UI highlight
                if ($(this).is(':checked')) {
                    $row.addClass('table-primary');
                } else {
                    $row.removeClass('table-primary');
                    $('#master').prop('checked', false);
                }

                // Count Update
                let totalChecked = $('.sub_chk:checked').length;
                if (totalChecked > 0) {
                    $('#selected_count').removeClass('d-none').text(totalChecked);
                } else {
                    $('#selected_count').addClass('d-none').text(0);
                }
            });

            // ৩. Bulk Delete Action with SweetAlert2 & AJAX
            $(document).on('click', '#bulk_delete_btn', function(e) {
                e.preventDefault();

                let selectedIds = [];
                $('.sub_chk:checked').each(function() {
                    selectedIds.push($(this).data('id'));
                });

                // যদি কোনো চেকবাক্স সিলেক্ট না থাকে
                if (selectedIds.length === 0) {
                    Swal.fire({
                        icon: 'warning',
                        title: 'No Items Selected',
                        text: 'Please select at least one item to delete.',
                        confirmButtonColor: '#0054a6'
                    });
                    return;
                }

                // Confirmation Alert
                Swal.fire({
                    title: 'Are you sure?',
                    text: `You are about to delete ${selectedIds.length} item(s)! This cannot be undone.`,
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#d33',
                    cancelButtonColor: '#6c757d',
                    confirmButtonText: 'Yes, Delete All',
                    cancelButtonText: 'Cancel',
                    reverseButtons: true
                }).then((result) => {
                    if (result.isConfirmed) {
                        // Loader Alert
                        Swal.fire({
                            title: 'Deleting...',
                            text: 'Please wait while we delete selected items.',
                            allowOutsideClick: false,
                            didOpen: () => {
                                Swal.showLoading();
                            }
                        });

                        // AJAX Request
                        $.ajax({
                            url: "{{ route('admin.supplier.bulk.delete') }}",
                            type: "POST",
                            data: {
                                ids: selectedIds,
                                _token: "{{ csrf_token() }}"
                            },
                            success: function(res) {
                                if (res.success) {
                                    Swal.fire({
                                        icon: 'success',
                                        title: 'Deleted!',
                                        text: res.message,
                                        timer: 1500,
                                        showConfirmButton: false
                                    }).then(() => {
                                        // Reload or DOM remove (Reload safer for pagination count)
                                        location.reload();
                                    });
                                } else {
                                    Swal.fire({
                                        icon: 'error',
                                        title: 'Failed',
                                        text: res.message ||
                                            'Something went wrong!',
                                    });
                                }
                            },
                            error: function(xhr) {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Server Error',
                                    text: xhr.responseJSON?.message ||
                                        'Failed to process request. Please try again.',
                                });
                            }
                        });
                    }
                });
            });

        });
    </script>
@endpush
